const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

// --- Configuração Inicial ---
const app = express();
app.use(cors());
app.use(express.json()); // Habilita o servidor para receber e entender JSON

// --- Conexão com o Banco de Dados MySQL ---
// ATENÇÃO: Substitua com os dados do seu banco de dados local!
const db = mysql.createConnection({
    host: 'localhost',
    user: 'alicext', // Geralmente 'root' em instalações locais
    password: '1234', // Coloque a senha do seu MySQL aqui
    database: 'foxstudy_db'
});

// Tenta conectar ao banco de dados
db.connect((err) => {
    if (err) {
        console.error('!!! Erro ao conectar ao MySQL:', err);
        return;
    }
    console.log('Conectado com sucesso ao banco de dados MySQL.');
});


// ===================================================================
// --- FUNÇÕES DA API ---
// ===================================================================

// 1. CREATE: Criação de Contas de Usuário
app.post('/register', (req, res) => {
    const { name, email, password } = req.body;

    const sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    
    db.query(sql, [name, email, password], (err, result) => {
        if (err) {
            // Verifica se o erro é de email duplicado
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ message: 'Este email já está cadastrado.' });
            }
            console.error(err);
            return res.status(500).json({ message: 'Erro ao registrar usuário.' });
        }
        res.status(201).json({ message: 'Usuário criado com sucesso!', userId: result.insertId });
    });
});

// 2. CREATE: Criação de Matérias (Atividades)
app.post('/materias', (req, res) => {
    // No futuro, o user_id virá do login. Por enquanto, vamos fixar como '1' para testes.
    const { nome, tipo, progresso, cor, user_id = 1 } = req.body;

    const sql = "INSERT INTO materias (nome, tipo, progresso, cor, user_id) VALUES (?, ?, ?, ?, ?)";

    db.query(sql, [nome, tipo, progresso, cor, user_id], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Erro ao criar matéria.' });
        }
        res.status(201).json({ message: 'Matéria criada com sucesso!', materiaId: result.insertId });
    });
});

// 3. READ: Leitura de todas as Matérias para os cartões
app.get('/materias', (req, res) => {
    // No futuro, buscaremos as matérias do usuário logado. Por enquanto, buscamos todas.
    const sql = "SELECT * FROM materias";

    db.query(sql, (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Erro ao buscar matérias.' });
        }
        // Se não houver matérias, retorna um array vazio (o que é o correto)
        res.status(200).json(results);
    });
});


// --- Iniciando o Servidor ---
const PORT = 5000;
app.listen(PORT, () => {
    // A MUDANÇA ESTÁ AQUI
    console.log(`Servidor rodando! Acesse em: http://localhost:${PORT}`);
});
